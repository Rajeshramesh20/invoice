<?php
namespace Twilio\Rest;

class Assistants extends AssistantsBase {
}
